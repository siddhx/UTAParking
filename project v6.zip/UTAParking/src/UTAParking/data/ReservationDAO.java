package UTAParking.data;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.sql.SQLConnection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import UTAParking.model.*;
import UTAParking.util.SQLConnection;

public class ReservationDAO {

	static SQLConnection DBMgr = SQLConnection.getInstance();
	/*
	 * This function returns the permit type of a given user
	 */
	public static String getPermitType(String username)
	{
		Statement stmt = null;
		Connection conn= null;
		String ParkingPermitType="";
		try
		{
			 conn = SQLConnection.getDBConnection();
			 stmt =conn.createStatement();
			  String getPermitTypeQuery = "SELECT parkingpermittype from USER WHERE USERNAME= '"+username+"'";
			  ResultSet rs = stmt.executeQuery(getPermitTypeQuery);
			  while(rs.next())
			  {
				  ParkingPermitType = rs.getString("username");
			  }
			 
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		return  ParkingPermitType;
	}
	
	/*
	 * This function makes a reservation and persists it in the reservation table
	 */
	
	public static int makeReservation(Reservation reserve) {
		Statement stmt = null;
		PreparedStatement pstmt;
		Connection conn= null;
		String ParkingPermitType="";
		String makeReservationQuery = "INSERT INTO reservation(start_time,end_time,reservation_uname,reservation_parkingId) ";
        makeReservationQuery += " VALUES ('"  
                + reserve.getStartTimeAsString() + "','"
                + reserve.getEndTimeAsString() + "','"
                + reserve.getUname() + "','"
                + reserve.getParkingId() + "')";
        
        System.out.println(makeReservationQuery);          
        System.out.println("inside ReservationDAO.makeReservation");
        int key = 0;
        try{		
			conn = SQLConnection.getDBConnection();  
			conn.setAutoCommit(false);   
//			stmt = conn.createStatement();
//			stmt.execute(makeReservationQuery);
//			ResultSet keys = stmt.getGeneratedKeys();
//			keys.next();
//			key = keys.getInt(1);
//			keys.close();
//			conn.commit();
			pstmt = conn.prepareStatement(makeReservationQuery, Statement.RETURN_GENERATED_KEYS);   
			pstmt.executeUpdate();
			ResultSet keys = pstmt.getGeneratedKeys();  
			keys.next();
			key = keys.getInt(1);
			keys.close();
			pstmt.close();
			conn.commit(); 
			conn.close();
	        System.out.println("query" + makeReservationQuery);			
			 
		}catch(SQLException sqle){
			sqle.printStackTrace();
		}
		finally {
			try {
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		};
		return key;
		
	}

	
	
	public static boolean isSpotAvailable(int reservation_parkingId, String start_time, String duration) {
		boolean status = false;

//		String query = "SELECT * FROM reservation "
//					+ "WHERE reservation_parkingId = "
//					+ reservation_parkingId ;
//					+ "IN start_time";
//////////////////////////////////////////////////////////////
// 		make the following an array data type
//        int permitId=0;
//        List<String> ids = new ArrayList<String>(); 

        String url = "jdbc:mysql://localhost:3306/arlington_parking?useSSL=false";
        String user = "root";
        String password = "root";
        
      String query = "SELECT * FROM reservation ";
//		+ "WHERE reservation_parkingId = 1 ";                   

        System.out.println("in isSpotAvailable");
        try  {

        	Connection con = DriverManager.getConnection(url, user, password);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
 
            while (rs.next()) {
//			store the ids in an array and return it              
//            	ids.add(rs.getString("id"));
                System.out.println("available"+rs.getString("reservation_parkingid"));
//                System.out.println("available"+rs.getString("id"));
           
            }             
        }catch(Exception e)  {
            e.printStackTrace();
        } 

//        return  ids;
/////////////////////////////////////////////////////////////
		return status;
	}
	
	/*	
	 * this function return a list of reservations for user
	*/	
		public List<Reservation> listReservations(String userName) {

			List<Reservation> reservationList = new ArrayList<Reservation>();
			
	        String url = "jdbc:mysql://localhost:3306/arlington_parking?useSSL=false";
	        String user = "root";
	        String password = "root";
	        
	        String query = "";
			query += "SELECT * FROM RESERVATION "
				+ "WHERE reservation_uname = '"+userName+"'";                   			
	        try
			{

				System.out.println("Inside parkingDAO");
				
	        	Connection conn = DriverManager.getConnection(url, user, password);
	            Statement stmt = conn.createStatement();
	            ResultSet result = stmt.executeQuery(query);
				
				while(result.next())
				{
					Reservation reservationObj = new Reservation();
					reservationObj.setStartTimeAsString(result.getString("start_time"));
					reservationObj.setEndTimeAsString(result.getString("end_time"));
					// reservationObj.setCapacity(Integer.toString(result.getInt("capacity")));
					// reservationObj.setFloor(Integer.toString(result.getInt("floor")));
					reservationObj.setId(result.getInt("reservation_id"));
					reservationList.add(reservationObj);
				}
			}
			catch(Exception e)
			{
				System.out.println(e);
				e.printStackTrace();
			}
			return reservationList;
		}

		/*
		 * the following function return a reservation from reservation table by id
		*/
		
		public List<Reservation> getReservationById(String reservationId, String uname) {
			System.out.println("inside res dao getReservationById()");

			List<Reservation> reservationList = new ArrayList<Reservation>();
			
	        String url = "jdbc:mysql://localhost:3306/arlington_parking?useSSL=false";
	        String user = "root";
	        String password = "root";
	        
	        String query = "";
			query += "SELECT * FROM RESERVATION "
				+ "WHERE reservation_id = '"+reservationId+"' "
				+ "AND reservation_uname ='" + uname+"'";                   			
	        try
			{

				System.out.println("Inside reservation DAO");
				
	        	Connection conn = DriverManager.getConnection(url, user, password);
	            Statement stmt = conn.createStatement();
	            ResultSet result = stmt.executeQuery(query);
				
				while(result.next())
				{
					Reservation reservationObj = new Reservation();
					reservationObj.setStartTimeAsString(result.getString("start_time"));
					reservationObj.setEndTimeAsString(result.getString("end_time"));
					reservationObj.setUname(result.getString("reservation_uname"));
					// reservationObj.setCapacity(Integer.toString(result.getInt("capacity")));
					// reservationObj.setFloor(Integer.toString(result.getInt("floor")));
					reservationObj.setId(result.getInt("reservation_id"));
					reservationObj.setParkingId(result.getInt("reservation_parkingId"));
					reservationList.add(reservationObj);
				}
			}
			catch(Exception e)
			{
				System.out.println(e);
				e.printStackTrace();
			}
			return reservationList;

		}

		public void updateReservation(String reservationId, String start_time, String end_time) {
			Statement stmt = null;
			Connection conn= null;
	        String Query = "UPDATE reservation "
	        		+ "SET  start_time = '" + start_time +"'"
	        		+ " , end_time = '" + end_time +"'"
	        		+ "WHERE reservation_id = " + reservationId;        
	        System.out.println(Query);
	        
			System.out.println("inside reservationDAO.updateReservation");
	        
	        try{		
				conn = SQLConnection.getDBConnection();  
				conn.setAutoCommit(false);   
				stmt = conn.createStatement();
				stmt.execute(Query);
				conn.commit();
		        // System.out.println("updateReservationQuery" + Query);			
				 
			}catch(SQLException sqle){
				sqle.printStackTrace();
			}
			finally {
				try {
					conn.close();
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			};			
		}

		public void deleteReservation(String reservationId) {
			Statement stmt = null;
			Connection conn= null;
	        String Query = "DELETE FROM reservation "
	        		+ "WHERE reservation_id = " + reservationId;        
	        System.out.println(Query);
	        
			System.out.println("inside reservationDAO.deleteReservation");
	        
	        try{		
				conn = SQLConnection.getDBConnection();  
				conn.setAutoCommit(false);   
				stmt = conn.createStatement();
				stmt.execute(Query);
				conn.commit();
				 
			}catch(SQLException sqle){
				sqle.printStackTrace();
			}
			finally {
				try {
					conn.close();
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			};				
		}
		
		
}
