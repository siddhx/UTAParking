package UTAParking.model;

import static org.junit.Assert.assertEquals;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.Locale;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)

public class ReservationTest {

	Reservation reservation;
	ReservationErrorMsgs rErrorMsgs;
	private LocalDateTime convertStringToDate(String string) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm", Locale.US).withResolverStyle(ResolverStyle.STRICT);
		return LocalDateTime.parse(string, formatter);
	}
	
	@Before
	public void setUp() throws Exception {
		reservation = new Reservation();
		rErrorMsgs = new ReservationErrorMsgs();
	}
	@FileParameters("src/UTAParking/model/Reservation_Test_Cases.csv")
	@Test
	public void test(int id, int parkingId, int paymentId, LocalDateTime startTime, LocalDateTime endtime, int hasCart, int hasCamera, int hasHistory, int isCanceled, int isDeleted, double totalPrice, String startTimeAsString, String endTimeAsString, String options, Object errorMsg, Object startTimeError, Object endTimeError){
		// get test reservation
		
		reservation.setStartTime(startTime);
		//reservation.setEndTime(endTime);
		//reservation.setparkingId(parkingid);
		reservation.setPaymentId(paymentId);
		reservation.setHasCamera(hasCamera);
		reservation.setHasCart(hasCart);
		reservation.setHasHistory(hasHistory);
		reservation.setIsCanceled(isCanceled);
		reservation.setId(id);
		reservation.setIsDeleted(isDeleted);
		reservation.setOptions(options);
		reservation.setTotalPrice(totalPrice);
		
		reservation.validateRequestTimes(reservation, rErrorMsgs);
		String dateAsString = null;
//		reservation.validateRequestStartTime(dateAsString);
//		reservation.validateRequestEndTime(dateAsString);
		
	
		assertEquals(errorMsg,rErrorMsgs.getErrorMsg());
		
		assertEquals(startTimeError,rErrorMsgs.getStartTimeError());
		
		assertEquals(endTimeError,rErrorMsgs.getEndTimeError());
		
	}
}
