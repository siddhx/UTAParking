package UTAParking.data;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import UTAParking.model.*;
import UTAParking.util.SQLConnection;
import java.sql.Statement;

public class ParkingDAO {
	
	static SQLConnection DBMgr = SQLConnection.getInstance();
	
	public List<Parking> listParking(String permitType) throws SQLException
	{
		String abd;
		List<Parking> parkingList = new ArrayList<Parking>();
		try
		{
			Connection conn = SQLConnection.getDBConnection();
			Statement stmt = conn.createStatement();
			System.out.println("Inside parkingDAO");
			String searchParkingQuery = "SELECT parkingtype,parkingarea_name,capacity,floor FROM PARKING WHERE parkingtype='"+permitType+"'";
			ResultSet result = stmt.executeQuery(searchParkingQuery);
			
			while(result.next())
			{
				Parking parkingObj = new Parking();
				parkingObj.setParkingType(result.getString("parkingtype"));
				parkingObj.setParkingAreaName(result.getString("parkingarea_name"));
				parkingObj.setCapacity(Integer.toString(result.getInt("capacity")));
				parkingObj.setFloor(Integer.toString(result.getInt("floor")));
				parkingList.add(parkingObj);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		return parkingList;
	}
	
	/*
	 * this function returns the id of given permit type
	 */
    public static List<String> getID(String permittype, String parkingarea_name) {
// 		make the following an array data type
        int permitId=0;
        List<String> ids = new ArrayList<String>(); 

        String url = "jdbc:mysql://localhost:3306/arlington_parking?useSSL=false";
        String user = "root";
        String password = "root";
        
      String query = "SELECT * FROM PARKING "
		+ "WHERE parkingtype = '"+permittype+"'" 
		+ "AND parkingarea_name =  + '" +parkingarea_name + "'";                   

        System.out.println("in here");
        try  {

        	Connection con = DriverManager.getConnection(url, user, password);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
 
            while (rs.next()) {
//			store the ids in an array and return it              
            	ids.add(rs.getString("id"));
            	
                System.out.println("added"+rs.getString("id"));
           
            }             
        }catch(Exception e)  {
            e.printStackTrace();
        } 

        return  ids;       
    }
    
/*
 * this function updates(reduces) capacity with every reservation
*/    
	public static void updateCapacity(int reservation_parkingId) {
		Statement stmt = null;
		Connection conn= null;
        String Query = "UPDATE parking "
        		+ "SET  availablespots = GREATEST(0, availablespots - 1) "
        		+ "WHERE id = " + reservation_parkingId;        
        System.out.println(Query);
        
		System.out.println("inside parkingDAO.updateCapacity");
        
        try{		
			conn = SQLConnection.getDBConnection();  
			conn.setAutoCommit(false);   
			stmt = conn.createStatement();
			stmt.execute(Query);
			conn.commit();
	        System.out.println("updateCapacityQuery" + Query);			
			 
		}catch(SQLException sqle){
			sqle.printStackTrace();
		}
		finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		
	}
/*	
 * this function return a list of parking spots which are available for a given permit type and parking area
*/	
	public List<Parking> listParkingSpots(String permitType, String parkingarea_name) {
		String abd;
		List<Parking> parkingList = new ArrayList<Parking>();
//		Statement stmt = null;
//		Connection conn= null;	
		
        String url = "jdbc:mysql://localhost:3306/arlington_parking?useSSL=false";
        String user = "root";
        String password = "root";
        
        String query = "";
		if (permitType.equals("Basic") | permitType.equals("Access")) {
		      query += "SELECT * FROM PARKING "
	    			+ "WHERE parkingtype = '"+permitType+"'" 
	    			+ "AND parkingarea_name =  + '" +parkingarea_name + "'";                   			

		}
		if (permitType.equals("Midrange")) {
		      query += "SELECT * FROM PARKING "
	    			+ "WHERE parkingarea_name = '" +parkingarea_name + "'"
	    			+ "AND parkingtype IN  ('Basic ','" + permitType+"')" ;
//  			+ "AND parkingtype IN  ('Midrange ','Basic')" ;
		}
		if (permitType.equals("Premium")) {
		      query += "SELECT * FROM PARKING "
	    			+ "WHERE parkingarea_name = '" +parkingarea_name + "'"
	    			+ "AND parkingtype IN  ('Basic ','Midrange','" + permitType+"')" ;
//			+ "AND parkingtype IN  ('Midrange ','Basic')" ;
		}
        try
		{

            
//			Connection conn = SQLConnection.getDBConnection();
//			Statement stmt = conn.createStatement();
			System.out.println("Inside parkingDAO");
			
        	Connection conn = DriverManager.getConnection(url, user, password);
            Statement stmt = conn.createStatement();
            ResultSet result = stmt.executeQuery(query);
            
//			ResultSet result = stmt.executeQuery(query);
			
			while(result.next())
			{
				Parking parkingObj = new Parking();
				parkingObj.setParkingType(result.getString("parkingtype"));
				parkingObj.setParkingAreaName(result.getString("parkingarea_name"));
				parkingObj.setAvailablespots(Integer.toString(result.getInt("availablespots")));
				parkingObj.setFloor(Integer.toString(result.getInt("floor")));
				parkingObj.setParkingid(Integer.toString(result.getInt("id")));
				parkingList.add(parkingObj);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		return parkingList;
	}

	public boolean canUpdate(String parkingId) {
		System.out.println("inside parking dao canUpdate()");
		boolean status = false;
		
        String url = "jdbc:mysql://localhost:3306/arlington_parking?useSSL=false";
        String user = "root";
        String password = "root";
        
        String query = "";
		query += "SELECT * FROM parking "
			+ "WHERE id = '"+parkingId+"' ";
        try
		{

			System.out.println("Inside parkingDAO");
			
        	Connection conn = DriverManager.getConnection(url, user, password);
            Statement stmt = conn.createStatement();
            ResultSet result = stmt.executeQuery(query);
			
			while(result.next())
			{
				String capacity = result.getString("availablespots");
				
				System.out.println("capacity is" + capacity);
				
				if (result.getString("availablespots").equals(0)) {
					System.out.println("cannot update");
					status = false;
				} else {
					System.out.println("can update");					
					status = true;
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		return status;
	}

	public void increaseCapacity(String parkingId) {
		Statement stmt = null;
		Connection conn= null;
        String Query = "UPDATE parking "
        		+ "SET  availablespots = GREATEST(0, availablespots + 1) "
        		+ "WHERE id = " + parkingId;        
        System.out.println(Query);
        
		System.out.println("inside parkingDAO.updateCapacity");
        
        try{		
			conn = SQLConnection.getDBConnection();  
			conn.setAutoCommit(false);   
			stmt = conn.createStatement();
			stmt.execute(Query);
			conn.commit();
	        System.out.println("updateCapacityQuery" + Query);			
			 
		}catch(SQLException sqle){
			sqle.printStackTrace();
		}
		finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};

		
	}
	/*
	 * Functions by lakshmi
	*/
	
	public List<Parking> listallParking() throws SQLException
	{
		String abd;
		System.out.println("inside list all parking");
		List<Parking> parkingList = new ArrayList<Parking>();
		try
		{
			Connection conn = SQLConnection.getDBConnection();
			Statement stmt = conn.createStatement();
			System.out.println("Inside parkingDAO");
			String searchParkingQuery = "SELECT parkingtype,parkingarea_name,capacity,floor,availablespots FROM PARKING WHERE availablespots >0";
			ResultSet result = stmt.executeQuery(searchParkingQuery);
			
			while(result.next())
			{
				Parking parkingObj = new Parking();
				parkingObj.setParkingType(result.getString("parkingtype"));
				parkingObj.setParkingAreaName(result.getString("parkingarea_name"));
				parkingObj.setCapacity(Integer.toString(result.getInt("capacity")));
				parkingObj.setFloor(Integer.toString(result.getInt("floor")));
				parkingObj.setAvailablespots(Integer.toString(result.getInt("availablespots")));
				parkingList.add(parkingObj);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		return parkingList;
	}
	
	public static void insertNewParkingArea(Parking parkingObj) throws SQLException
	{
		try
		{
			Connection conn = SQLConnection.getDBConnection();
			Statement stmt = conn.createStatement();
			System.out.println("Inside parkingDAO");
			if(parkingObj.getCart().equals(""))
				parkingObj.setCart("0.00");
			if(parkingObj.getCamera().equals(""))
				parkingObj.setCamera("0.00");
			if(parkingObj.getHistory().equals(""))
				parkingObj.setHistory("0.00");
				
			String insertParkingQuery = "INSERT INTO PARKING (parkingtype,parkingarea_name,capacity,floor,cart,camera,history,availablespots) VALUES ("
					
				+"'"+ parkingObj.getParkingType() + "',"
				+"'"+ parkingObj.getParkingAreaName() + "',"		
				+ Integer.parseInt(parkingObj.getCapacity()) + ","	
				+ Integer.parseInt(parkingObj.getFloor())+ ","	
				+Float.parseFloat(parkingObj.getCart()) +  ","
				+Float.parseFloat(parkingObj.getCamera()) + ","
				+ Float.parseFloat(parkingObj.getHistory()) + "," 
				+ Integer.parseInt(parkingObj.getCapacity()) +")" ;
			stmt.executeUpdate(insertParkingQuery);
			conn.commit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}	
	
	public static void modifyParkingArea(Parking parkingObj) throws SQLException
	{
		try
		{
			Connection conn = SQLConnection.getDBConnection();
			Statement stmt = conn.createStatement();
			System.out.println("Inside parkingDAO");
			if(parkingObj.getCart().equals(""))
				parkingObj.setCart("0.00");
			if(parkingObj.getCamera().equals(""))
				parkingObj.setCamera("0.00");
			if(parkingObj.getHistory().equals(""))
				parkingObj.setHistory("0.00");
				
			String insertParkingQuery = "UPDATE PARKING SET parkingtype =" +"'"+ parkingObj.getParkingType() + "'," 
												+"parkingarea_name = " +"'"+ parkingObj.getParkingAreaName() + "',"
												+"capacity = " + Integer.parseInt(parkingObj.getCapacity()) + ","
												+"floor="		+ Integer.parseInt(parkingObj.getFloor())+ ","	
													+"cart="	+Float.parseFloat(parkingObj.getCart()) +  ","
													+	"camera="+Float.parseFloat(parkingObj.getCamera()) + ","
													+"history="	+ Float.parseFloat(parkingObj.getHistory()) + ","
													+"availablespots="	+ Float.parseFloat(parkingObj.getAvailablespots ()) + 
													"where id="+parkingObj.getParkingid()  ;
			System.out.println("capacity"+parkingObj.getCapacity());
			System.out.println("id"+parkingObj.getParkingid());
				
						
					
				
			stmt.executeUpdate(insertParkingQuery);
			conn.commit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
		
		//check if a parking area name already exists in DB or not
		public static boolean uniqueParkingAreaName(String areaName) {  
			Statement stmt = null;   
			Connection conn = null;  
			try {   
				conn = SQLConnection.getDBConnection();  
				stmt = conn.createStatement();
				String searchUsername = " SELECT * from PARKING WHERE parkingarea_name = '"+areaName+"'";
				ResultSet parkingList = stmt.executeQuery(searchUsername);
				ArrayList<Parking> parkingListInDB = new ArrayList<Parking>();
				while (parkingList.next()) {
					Parking pobj = new Parking(); 
					parkingListInDB.add(pobj);	 
				} 
				return (parkingListInDB.isEmpty());
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					conn.close();
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}};
			return false;
		}
		public static Parking getParkingDetailsbyID(String parkingId) throws SQLException
		{
			Connection conn = SQLConnection.getDBConnection();
			Statement stmt = conn.createStatement();
			Parking pobj = new Parking();
			try
			{
				
				System.out.println("Inside parkingDAO");
				String searchParking = " SELECT * from PARKING WHERE id = '"+parkingId+"'";
				ResultSet parkingList = stmt.executeQuery(searchParking);
				//ArrayList<Parking> parkingListInDB = new ArrayList<Parking>();
				
				while (parkingList.next()) {
					
					pobj.setParkingid(parkingList.getString("id"));
					pobj.setParkingType(parkingList.getString("parkingtype"));
					pobj.setParkingAreaName(parkingList.getString("parkingarea_name"));
					pobj.setCapacity(parkingList.getString("capacity"));
					pobj.setCart(parkingList.getString("cart"));
					pobj.setFloor(parkingList.getString("floor"));
					pobj.setCamera(parkingList.getString("camera"));
					pobj.setHistory(parkingList.getString("history"));
					pobj.setAvailablespots(parkingList.getString("availablespots"));
				} 
				
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			return pobj;
		}
		
		public static ArrayList<Parking>  getParkingDetailsbyName(String name) throws SQLException
		{
			Connection conn = SQLConnection.getDBConnection();
			Statement stmt = conn.createStatement();
			
			ArrayList<Parking> parkingListInDB = new ArrayList<Parking>();
			try
			{
				
				System.out.println("Inside parkingDAO");
				String searchParking = " SELECT * from PARKING WHERE parkingarea_name = '"+name+"'";
				ResultSet parkingList = stmt.executeQuery(searchParking);
			
				
				while (parkingList.next()) {
					Parking pobj = new Parking();
					pobj.setParkingid(parkingList.getString("id"));
					pobj.setParkingType(parkingList.getString("parkingtype"));
					pobj.setParkingAreaName(parkingList.getString("parkingarea_name"));
					pobj.setCapacity(parkingList.getString("capacity"));
					pobj.setCart(parkingList.getString("cart"));
					pobj.setFloor(parkingList.getString("floor"));
					pobj.setCamera(parkingList.getString("camera"));
					pobj.setHistory(parkingList.getString("history"));
					parkingListInDB.add(pobj);
				} 
				
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			return parkingListInDB;
		}
		
		public static String getCapacity(Parking parkingObj)
		{
			Statement stmt = null;   
			String Status="";
			Connection conn = null;  
			try
			{
				 conn = SQLConnection.getDBConnection();
				 stmt =conn.createStatement();
				 //System.out.println("inside userDAO");
				  String getStatusQuery = "SELECT capacity from PARKING WHERE id= '"+parkingObj.getParkingid()+"'";
				  //System.out.println("inside DAO and username is "+username);
				  ResultSet rs = stmt.executeQuery(getStatusQuery);
				  while(rs.next())
				  {
					  Status = rs.getString("capacity");
					  System.out.println("Status in DB is"+ Status);
				  }
				 
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally {
				try {
					conn.close();
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}};
			return Status;
		}		
		
}
