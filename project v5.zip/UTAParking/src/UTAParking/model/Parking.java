package UTAParking.model;
import UTAParking.controller.parkingAreaControllerforPM;

import UTAParking.data.ParkingDAO;

public class Parking {

	private String parkingid;
	private String parkingType;
	private String parkingAreaName;
	private String capacity;
	private String floor;
	private String cart;
	private String camera;
	private String history;
	private String availablespots;
	
	public String getParkingid() {
		return parkingid;
	}
	public void setParkingid(String parkingid) {
		this.parkingid = parkingid;
	}
	public String getParkingType() {
		return parkingType;
	}
	public void setParkingType(String parkingType) {
		this.parkingType = parkingType;
	}
	public String getParkingAreaName() {
		return parkingAreaName;
	}
	public void setParkingAreaName(String parkingAreaName) {
		this.parkingAreaName = parkingAreaName;
	}
	public String getCapacity() {
		return capacity;
	}
	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}
	public String getFloor() {
		return floor;
	}
	public void setFloor(String floor) {
		this.floor = floor;
	}
	public String getCart() {
		return cart;
	}
	public void setCart(String cart) {
		this.cart = cart;
	}
	public String getCamera() {
		return camera;
	}
	public void setCamera(String camera) {
		this.camera = camera;
	}
	public String getHistory() {
		return history;
	}
	public void setHistory(String history) {
		this.history = history;
	}
	public String getAvailablespots() {
		return availablespots;
	}
	public void setAvailablespots(String availablespots) {
		this.availablespots = availablespots;
	}
	
	/******************************* VALIDATIONS ***********************************/
	public void validateParking(Parking parkingObj,ParkingErrorMsgs PerrorMsgs,String action)
	{
		switch(action)
		{
		case "addArea":
			PerrorMsgs.setParkingAreaNameError(validateAreaName(parkingObj.getParkingAreaName()));
			if(PerrorMsgs.getParkingAreaNameError().equals(""))
			{
				PerrorMsgs.setParkingAreaNameError(validateUniqueAreaName(parkingObj.getParkingAreaName()));
			}
			PerrorMsgs.setCapacityError (validateCapacity(parkingObj.getCapacity()));
			PerrorMsgs.setFloorError(validateFloor(parkingObj.getFloor()));
			PerrorMsgs.setCartError(validateCart(parkingObj.getCart()));
			PerrorMsgs.setCameraError(validateCamera(parkingObj.getCamera()));
			PerrorMsgs.setHistoryError(validateHistory(parkingObj.getHistory()));
			//PerrorMsgs.setAvailableSpotError(validateAvailableSpots);
			PerrorMsgs.setErrorMsg();
			break;
		case "SearchArea":
			//System.out.println("hellooooo"+parkingObj.getParkingAreaName()+" error"+PerrorMsgs.getParkingAreaNameError());
			
			PerrorMsgs.setParkingAreaNameError(validateAreaName(parkingObj.getParkingAreaName()));
			PerrorMsgs.setErrorMsg();
			break;
		case "modifyArea":
			PerrorMsgs.setCapacityError (validateCapacityforModify(parkingObj));
			PerrorMsgs.setFloorError(validateFloor(parkingObj.getFloor()));
			PerrorMsgs.setCartError(validateCart(parkingObj.getCart()));
			PerrorMsgs.setCameraError(validateCamera(parkingObj.getCamera()));
			PerrorMsgs.setHistoryError(validateHistory(parkingObj.getHistory()));
			PerrorMsgs.setErrorMsg();
			break;
		default: 
			//System.out.println("Invalid action");
			break;
		}
		
	}


	
	public String validateAreaName(String name) {
		String result="";
		//System.out.println("name inside val "+name);
		name = name.trim(); //trim out trailing and leading spaces	
		if( name.length()==0 )
			result = "Parking Area Name cannot be null";
		else
		if (!stringSize(name,3,20))
			result= "Parking Area name must be between 3 and 20 characters";
		else
			if (!name.matches("^[a-zA-Z 0-9]+$") )
				result="Parking Area name must only contain alphabets and numbers";	
		else
			result="";

				
		return result;
	}
	
	public String validateCapacity(String capacity)
	{
		String result="";
		
		if(capacity.equals(""))
			result="Capacity cannot be empty";
		else{
			if (!capacity.matches("^[0-9]*$"))
				result="Capacity must be a number";
			else
				if(Integer.parseInt(capacity)>=500)
					result="Capacity cannot be greater than 500";
			
			else
				result="";
				
		}
			return result;
	}
	
	public String validateCapacityforModify(Parking parkingObj)
	{
		String result="";
		String a=parkingObj.getAvailablespots();
		String b=parkingObj.getParkingType();
		b=parkingObj.getParkingid();
		if(parkingObj.capacity.equals("")) //|| capacity.length()==0
			result="Capacity cannot be empty";
		else{
			if (!parkingObj.capacity.matches("^[0-9]*$"))
				result="Capacity must be a number";
			else
				if(Integer.parseInt(parkingObj.capacity)>500)
					result="Capacity cannot be greater than 500";
			
			
			}
				
				
		
		//System.out.println(result);
			return result;
	}
	
	public String validateFloor(String floor)
	{
		String result="";
	/*	if(floor==null)
	 		floor="";
			
		else*/
		floor= floor.trim();
		
		if(floor.equals("")  )
			result="Floor cannot be empty";
		else
			if(Integer.parseInt(floor)==0)
				result="Floor cannot be 0";
		
		return result;
	}
	public String validateUniqueAreaName(String areaName)
	{
		String result="";
		if(ParkingDAO.uniqueParkingAreaName(areaName)==false)
				{
					result="Area Name already exist";
				}
		return result;
	}
	
	public String validateCart(String name) {
		String result="";
		
			if (!name.matches("^[0-9.]*$"))
			result="Cart value must be a number";
		
		
		return result;
	}
	
	public String validateCamera(String name) {
		String result="";
		/*if(name==null)
			result="";
		else*/
			if (!name.matches("^[0-9.]*$"))
			result="Camera value must be a number";
		
		
		return result;
	}
	
	public String validateHistory(String name) {
		String result="";
		
			if (!name.matches("^[0-9.]*$"))
			result="History value must be a number";
		
		return result;
	}

	/************* AUXILIARY FUNCTIONS *************/
	private boolean stringSize(String string, int min, int max) {
		return string.length()>=min && string.length()<=max;
	}	
	
}
