package UTAParking.model;

public class ParkingErrorMsgs {
	
	private String parkingid;
	private String parkingTypeError="";
	private String parkingAreaNameError="";
	private String capacityError="";
	private String floorError="";
	private String cartError="";
	private String cameraError="";
	private String historyError="";
	private String availableSpotError="";
	private String errorMsg="";
	
	
	public String getErrorMsg() {
		return errorMsg;
	}
	
	public void setErrorMsg() {
		if( !parkingAreaNameError.equals("") || !capacityError.equals("") || 
				!floorError.equals("") ||  !cartError.equals("") || !cameraError.equals("") || !historyError.equals("")){
			this.errorMsg= "Please correct following errors :";}
		
	}
	 
	
	public String getParkingTypeError() {
		return parkingTypeError;
	}
	
	public String getParkingAreaNameError() {
		return parkingAreaNameError;
	}
	public void setParkingAreaNameError(String parkingAreaNameError) {
		this.parkingAreaNameError = parkingAreaNameError;
	}
	public String getCapacityError() {
		return capacityError;
	}
	public void setCapacityError(String capacityError) {
		this.capacityError = capacityError;
	}
	public String getFloorError() {
		return floorError;
	}
	public void setFloorError(String floorError) {
		this.floorError = floorError;
	}
	public String getCartError() {
		return cartError;
	}
	public void setCartError(String cartError) {
		this.cartError = cartError;
	}
	public String getCameraError() {
		return cameraError;
	}
	public void setCameraError(String cameraError) {
		this.cameraError = cameraError;
	}
	public String getHistoryError() {
		return historyError;
	}
	public void setHistoryError(String historyError) {
		this.historyError = historyError;
	}

	public String getAvailableSpotError() {
		return availableSpotError;
	}

	public void setAvailableSpotError(String availableSpotError) {
		this.availableSpotError = availableSpotError;
	}

}
