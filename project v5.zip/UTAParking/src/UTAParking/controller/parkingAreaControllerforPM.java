package UTAParking.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import UTAParking.data.ParkingDAO;
import UTAParking.data.UserDAO;
import UTAParking.model.Parking;
import UTAParking.model.ParkingErrorMsgs;
import UTAParking.model.User;
import UTAParking.model.UserErrorMsgs;

/**
 * Servlet implementation class parkingAreaControllerforPM
 */
@WebServlet("/parkingAreaControllerforPM")
public class parkingAreaControllerforPM extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public parkingAreaControllerforPM() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		HttpSession session = request.getSession();		
		String url="/addNewParkingArea.jsp"; 

		//add new parking area if all validations fine\
		
		if (action.equalsIgnoreCase("addArea")) 
		{			
			Parking parkingObj = new Parking();
			ParkingErrorMsgs PerrorMsgs = new ParkingErrorMsgs();
			session.removeAttribute("successMsg");
			parkingObj.setParkingAreaName(request.getParameter("parkingAreaName"));
			parkingObj.setParkingType(request.getParameter("permittype"));
			parkingObj.setFloor(request.getParameter("floor"));
			parkingObj.setCapacity(request.getParameter("capacity"));
			parkingObj.setCart(request.getParameter("cart"));
			parkingObj.setCamera(request.getParameter("camera"));
			parkingObj.setHistory(request.getParameter("history"));
			//parkingObj.setAvailablespots(request.getParameter("availableSpots"));
			
			//String[] checkedValues = request.getParameterValues("floor");
			
			/*if(checkedValues!=null && checkedValues.length>0){
				for(int i=0;i<checkedValues.length;i++)
				{
					System.out.println("checked value : "+checkedValues[i]);//debug
					parkingObj.setFloor(checkedValues[i]);
					//ParkingDAO.insertNewParkingArea(parkingObj);
				}
			}
			*/
			System.out.println("Floor selected :"+request.getParameter("floor"));
			parkingObj.validateParking(parkingObj, PerrorMsgs,action);
			
			session.setAttribute("Parking", parkingObj);
			session.setAttribute("errorMsgs",PerrorMsgs);	
			System.out.println(PerrorMsgs.getParkingAreaNameError()); //debug
			System.out.println("area name is "+parkingObj.getParkingAreaName()); //debug
			System.out.println("Error Msg : "+PerrorMsgs.getErrorMsg());
			
			if ( PerrorMsgs.getErrorMsg().equals("") ) { // exists		
				try {
					System.out.println("inside add parking area");
					ParkingDAO.insertNewParkingArea(parkingObj);
					session.removeAttribute("Parking");
					session.removeAttribute("errorMsgs");
					session.setAttribute("successMsg", "Parking Area successfully added");
					url = "/addNewParkingArea.jsp";
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}	
		
				
			/*if(PerrorMsgs.getParkingAreaNameError().equals(""))
			{
				//parkingObj.verifyUniqueParkingAreaName(parkingObj,PerrorMsgs);
			}*/
			
				/*parkingObj.setFloor(request.getParameter("floor"));
				System.out.println("floor"+request.getParameter("floor"));
				String[] checkedValues = request.getParameterValues("floor");
				
				
				if(checkedValues.equals(null) || checkedValues.length<=0){
					PerrorMsgs.setFloorError("Please select floor");
					session.setAttribute("errorMsgs", PerrorMsgs);
				}
				else
				{
					for(int i=0;i<checkedValues.length;i++)
					{
						System.out.println("checked value : "+checkedValues[i]);//debug
						parkingObj.setFloor(checkedValues[i]);
						ParkingDAO.insertNewParkingArea(parkingObj);
					}
				}
			 */
			/*if (PerrorMsgs.getErrorMsg().equals(null) || PerrorMsgs.getErrorMsg().equals("") ) { // exists		
				//redirect to user profile
				url = "/addNewParkingArea.jsp";
				System.out.println("inside if");
				//user = UserDAO.getUserForAdmin(request.getParameter("username"));				
				//session.setAttribute("User", user); //pre-populate fields 
			}	
			else
				System.out.println("No error");*/
		
		}
		if (action.equalsIgnoreCase("searchArea")) 
		{
			url="/parkingSearchResultforManager.jsp";
			Parking parkingObj = new Parking();
			ArrayList<Parking> parkingList = new ArrayList<Parking>();
			ParkingErrorMsgs PerrorMsgs = new ParkingErrorMsgs();
			parkingObj.setParkingAreaName(request.getParameter("PermitAreasearch"));
			parkingObj.validateParking(parkingObj, PerrorMsgs,action);
			try {
			if ( PerrorMsgs.getErrorMsg().equals(""))
				{
				System.out.println("area error msg"+PerrorMsgs.getErrorMsg()+" "+ PerrorMsgs.getParkingAreaNameError());
				parkingList= ParkingDAO.getParkingDetailsbyName(request.getParameter("PermitAreasearch"));
					session.setAttribute("parkingList", parkingList);
				}
			else{
				session.setAttribute("searchparkingAreaNameError", PerrorMsgs.getParkingAreaNameError());
			}
			}
		 catch (SQLException e) {
			
			e.printStackTrace();
		}
			
		}
		else
			if (action.equalsIgnoreCase("editselectedArea")) 
			{
				url="/modifyParkingArea.jsp";
				Parking parkingObj = new Parking();
				ParkingErrorMsgs PerrorMsgs = new ParkingErrorMsgs();
				parkingObj.setParkingid(request.getParameter("editParking"));
				//parkingObj.validateParking(parkingObj, PerrorMsgs,action);
				try {
				if ( PerrorMsgs.getErrorMsg().equals(""))
					{
						parkingObj= ParkingDAO.getParkingDetailsbyID(request.getParameter("editParking"));
						session.setAttribute("Parking", parkingObj);
					}
				}
			 catch (SQLException e) {
				
				e.printStackTrace();
			}
				
			}
		else
		if (action.equalsIgnoreCase("modifyArea")) 
		{		url="/modifyParkingArea.jsp";	
			Parking parkingObj = new Parking();
			ParkingErrorMsgs PerrorMsgs = new ParkingErrorMsgs();
			session.removeAttribute("successMsg");
			System.out.println("Id"+request.getParameter("parkingid"));
			parkingObj.setParkingid(request.getParameter("parkingid"));
			parkingObj.setParkingAreaName(request.getParameter("parkingAreaName"));
			parkingObj.setParkingType(request.getParameter("permittype"));
			parkingObj.setFloor(request.getParameter("floorSelect"));
			parkingObj.setCapacity(request.getParameter("capacity"));
			parkingObj.setCart(request.getParameter("cart"));
			parkingObj.setCamera(request.getParameter("camera"));
			parkingObj.setHistory(request.getParameter("history"));
			parkingObj.setAvailablespots(request.getParameter("availableSpots"));
			
			
			parkingObj.validateParking(parkingObj, PerrorMsgs,action);
			
			session.setAttribute("Parking", parkingObj);
			session.setAttribute("errorMsgs",PerrorMsgs);	
			System.out.println(PerrorMsgs.getParkingAreaNameError()); //debug
			System.out.println("area name is "+parkingObj.getParkingAreaName()); //debug
			System.out.println("Error Msg : "+PerrorMsgs.getErrorMsg());
			
			if ( PerrorMsgs.getErrorMsg().equals("") ) { // exists		
				try {
					System.out.println("inside add parking area");
					ParkingDAO.modifyParkingArea(parkingObj);
					session.setAttribute("Parking",parkingObj);
					//session.removeAttribute("errorMsgs");
					session.setAttribute("successMsg", "Parking Area successfully updated");
					url = "/modifyParkingArea.jsp";
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}	
		
				
		
		
		}
		else if (action.equalsIgnoreCase("goHome")) 
		{
			
			System.out.println("inside else go home");
			session.removeAttribute("Parking");
			session.removeAttribute("errorMsgs");
			session.removeAttribute("successMsg");
			session.removeAttribute("parkingList");
			session.removeAttribute("searchparkingAreaNameError");
			url = "/managerHome.jsp"; //redirect to home page
		}
		getServletContext().getRequestDispatcher(url).forward(request, response);
	}

}
