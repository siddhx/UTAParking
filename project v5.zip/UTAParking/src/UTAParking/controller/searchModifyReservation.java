package UTAParking.controller;

import java.io.IOException;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import UTAParking.data.ParkingDAO;
import UTAParking.data.ReservationDAO;
import UTAParking.model.Reservation;

/**
 * Servlet implementation class searchModifyReservation
 */
@WebServlet("/searchModifyReservation")
public class searchModifyReservation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public searchModifyReservation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "/searchReservationUserToEdit.jsp";
		HttpSession session = request.getSession();	
		
		System.out.println("via modify reservation do get");
		
		ReservationDAO reservation = new ReservationDAO();
		String userName =  (String) session.getAttribute("username");
		List<Reservation> reservationList = reservation.listReservations(userName);

//		for(int i = 0; i < reservationList.size(); i++) {
//			System.out.println(reservationList.get(i).getId());						
//			System.out.println(reservationList.get(i).getStartTimeAsString());			
//			System.out.println(reservationList.get(i).getEndTimeAsString());
//		}
		request.setAttribute("reservationList",reservationList);		
		getServletContext().getRequestDispatcher(url).forward(request, response);	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "/editReservationUser.jsp";
		HttpSession session = request.getSession();	
		String action=request.getParameter("action");
		String reservationId = request.getParameter("reservationId");
		Enumeration<String> parameterNames = request.getParameterNames();
	
		System.out.println("inside search  modify reservation do post");		

		if (action.equalsIgnoreCase("search")) {
			System.out.println("action is :" + action);		

			System.out.println("reservationId :"+reservationId);
			/*
			 * query the reservation table with given reservationId
			 * 	and add it to request
			*/
			
			ReservationDAO reserve = new ReservationDAO();
			String reservation_uname =  (String) session.getAttribute("username");
			
			List<Reservation> reservationList = reserve.getReservationById(reservationId, reservation_uname);
			/*for (int i = 0; i < reservationList.size(); i++) {
				System.out.println(reservationList.get(i).getUname());				
				System.out.println(reservationList.get(i).getId());
				System.out.println(reservationList.get(i).getStartTimeAsString());				
				System.out.println(reservationList.get(i).getEndTimeAsString());				
				
			}*/
			request.setAttribute("reservationList",reservationList.get(0));

			getServletContext().getRequestDispatcher(url).forward(request, response);			

		}
    	ParkingDAO parking = new ParkingDAO();
		ReservationDAO reservation = new ReservationDAO();
		
		if (action.equalsIgnoreCase("update")) {
			System.out.println("action is :" + action);	
    		String parkingId=request.getParameter("parkingId");			
	        if (request.getParameterMap().containsKey("updateReservation")) {
	        	/*
	        	 * verify the start and end time
	        	 * i.e. find if based on new times, 
	        	 * 			is there a parking slot available.
	        	 * 				query the parking table with the parkingid stored with reservation
	        	 * 			and if capacity is more than 1 
	        	 * 				allow the update of start or end time
	        	*/
				

	    		String start_time=request.getParameter("start_time");
	    		String end_time=request.getParameter("end_time");
	    		
	        	boolean canUpdate = parking.canUpdate(parkingId);
	            System.out.println("status is " + canUpdate);	        	
//	            String submitType = request.getParameter("updateReservation");
	            System.out.println("update the record");
	            
	            reservation.updateReservation(reservationId, start_time, end_time);
				parking.updateCapacity(Integer.parseInt(reservationId));
				url = "/userHome.jsp";
				getServletContext().getRequestDispatcher(url).forward(request, response);					
				
				
	        }
	        if (request.getParameterMap().containsKey("deleteReservation")) {
	            String submitType = request.getParameter("deleteReservation");
	            System.out.println("delete the record");
	            
	            reservation.deleteReservation(reservationId);
				parking.increaseCapacity(parkingId);	            
				url = "/userHome.jsp";
				getServletContext().getRequestDispatcher(url).forward(request, response);						            
;
	        }	        
//	        while (parameterNames.hasMoreElements()) {
//	        	 
//	            String paramName = parameterNames.nextElement();
//	            System.out.println(paramName);
//	        }
	        
		}		
		
	}

}
