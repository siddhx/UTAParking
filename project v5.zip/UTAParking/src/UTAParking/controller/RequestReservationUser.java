package UTAParking.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import UTAParking.data.ParkingDAO;
import UTAParking.data.ReservationDAO;
import UTAParking.model.Parking;
import UTAParking.model.Reservation;
import UTAParking.model.ReservationErrorMsgs;
import UTAParking.model.User;

/**
 * Servlet implementation class RequestReservationUser
 */
@WebServlet("/RequestReservationUser")
public class RequestReservationUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RequestReservationUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String url = "/requestParking.jsp";
		HttpSession session = request.getSession();	
		ParkingDAO parking = new ParkingDAO();
		Reservation reserve = new Reservation();
		
		String action = request.getParameter("action");
		String permittype = request.getParameter("permittype");
		String parkingarea_name = request.getParameter("parkingarea_name");
		System.out.println("form action "+action);
		if (action.equals("search")) {
			System.out.println("inside search");			
			String start_time = request.getParameter("startTime");
			String end_time = request.getParameter("duration");
			session.setAttribute("start_time",start_time);
			session.setAttribute("end_time", end_time);		
			
			/*
			 * validations using the functions in Reservation.java
			*/
/*			ReservationErrorMsgs RerrorMsgs = new ReservationErrorMsgs();
//			reserve.convertStringToDate(start_time);
			System.out.println(reserve.convertStringToDate(start_time));*/
			
			List<Parking> parkingList = parking.listParkingSpots(permittype, parkingarea_name);
			request.setAttribute("parkingList",parkingList);
			getServletContext().getRequestDispatcher(url).forward(request, response);
			
		} 
		if (action.equals("reserve")) {



			System.out.println("inside reserve action");
	        
			ReservationDAO reservation = new ReservationDAO();

			System.out.println(request.getParameter("parkingid"));
			int reservation_parkingId = Integer.parseInt(request.getParameter("parkingid"));

			//get the current user name from session
			String reservation_uname =  (String) session.getAttribute("username");
			

			reserve.setStartTimeAsString((String) session.getAttribute("start_time"));
			reserve.setEndTimeAsString((String) session.getAttribute("end_time"));
			reserve.setParkingId(reservation_parkingId);
			reserve.setUname(reservation_uname);
			
			reservation.makeReservation(reserve);
			parking.updateCapacity(reservation_parkingId);
			getServletContext().getRequestDispatcher(url).forward(request, response);			
			
		}


//		doGet(request, response);
	}

}
