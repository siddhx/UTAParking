package arlington_parking_app.data;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import arlington_parking_app.model.User;
import arlington_parking_app.util.SQLConnection;

public class UserDAO {

	static SQLConnection DBMgr = SQLConnection.getInstance();

	
	public static void registerUser(User user) {
		Statement stmt = null;   
		Connection conn = SQLConnection.getDBConnection();  
		String registerUser = "INSERT INTO USER (utaid,username,first_name,last_name,password,email,phone,role,state,address,zipcode,parkingpermitype,city) ";					
		registerUser += " VALUES ('"  
				+ user.getUtaId() + "','"
				+ user.getUsername() + "','"		
				+ user.getFirstName() + "','"
				+ user.getLastName() + "','" 
				+ user.getPassword()  + "','"
				+ user.getEmail() + "','"
				+ user.getPhone() + "','"		
				+ user.getRole() + "','"
				+ user.getState() + "','"
				+user.getAddress() + "','"
				+user.getZipcode() + "','"
				+user.getParkingpermitype() + "','"
				+ user.getCity() + "')" ;
		try {   
		conn = SQLConnection.getDBConnection();  
		conn.setAutoCommit(false);   
		stmt = conn.createStatement();
		stmt.executeUpdate(registerUser);
		conn.commit();					 
	} catch (SQLException sqle) { 
		sqle.printStackTrace();
	} finally {
		try {
			conn.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		};
	}
	} 
	
	
	//get a user based on username (needed for login)
	public static User getUser(String username) {
		Statement stmt = null;   
		Connection conn = null;  
		User user = new User();
		try {   
			conn = SQLConnection.getDBConnection();  
			stmt = conn.createStatement();
			String searchUsername = " SELECT * from USER WHERE USERNAME = '"+username+"'";
			ResultSet userList = stmt.executeQuery(searchUsername);
			while(userList.next()) {
				int id = userList.getInt("id");
				String utaId = userList.getString("utaid");
				String firstName  = userList.getString("first_name");
				String lastName  = userList.getString("last_name");
				String password = userList.getString("password");
				String email  = userList.getString("email");
				String role  = userList.getString("role");
			    String address = userList.getString("address");
			    String parkingpermitype = userList.getString("parkingpermitype");
			    String state = userList.getString("state");
			    String zipcode = userList.getString("zipcode");
			    String phone = userList.getString("phone");
			    String city = userList.getString ("city");
				
				//set User
				user.setId(id);
				user.setFirstName(firstName);
				user.setLastName(lastName);
				user.setUsername(username);
				user.setPassword(password);
				user.setEmail(email);
				user.setUtaId(utaId);
				user.setAddress(address);
				user.setRole(role);
				user.setParkingpermitype(parkingpermitype);
				user.setState(state);
				user.setZipcode(zipcode);
				user.setPhone(phone);
				user.setCity(city);
				
			
				
			}
			
			} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		return user;
	}
	//update a user for edit profile
		public static void updateUser(User user) {
			Statement stmt = null;   
			Connection conn = SQLConnection.getDBConnection();  
			String updateUser = "UPDATE USER SET utaid='"+user.getUtaId()
			+"',first_name='"+user.getFirstName()+"',last_name='"+user.getLastName()+"',password='"
					+user.getPassword()+"',email='"+user.getEmail()+" ";		
			updateUser += " WHERE USERNAME='"+user.getUsername()+"'";
			try {   
			conn = SQLConnection.getDBConnection();  
			conn.setAutoCommit(false);   
			stmt = conn.createStatement();
			stmt.executeUpdate(updateUser);
			conn.commit();					 
		} catch (SQLException sqle) { 
			sqle.printStackTrace();
		} finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			};
		}
		}
	
	//check if a username already exists in DB or not
	public static boolean uniqueUsername(String username) {  
		Statement stmt = null;   
		Connection conn = null;  
		try {   
			conn = SQLConnection.getDBConnection();  
			stmt = conn.createStatement();
			String searchUsername = " SELECT * from USER WHERE USERNAME = '"+username+"'";
			ResultSet userList = stmt.executeQuery(searchUsername);
			ArrayList<User> userListInDB = new ArrayList<User>();
			while (userList.next()) {
				User user = new User(); 
				userListInDB.add(user);	 
			} 
			return (userListInDB.isEmpty());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		return false;
	}
	public static void deleteUser(String username) {
		Statement stmt = null;   
		Connection conn = null;  
		try {   
			conn = SQLConnection.getDBConnection();  
			stmt = conn.createStatement();
			String delete = " DELETE from USER WHERE username = '"+username+"' LIMIT 1 ";
			stmt.executeUpdate(delete);
			conn.commit();			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		}
		
}