package arlington_parking_app.data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import arlington_parking_app.model.Reservation;
import arlington_parking_app.model.ReservationDetails;
import arlington_parking_app.util.SQLConnection;

public class ReservationDAO { 
	 
	static SQLConnection DBMgr = SQLConnection.getInstance(); 
	
	//insert new reservation and return auto-gen PK
	public static int insertReservation(Reservation reservation) {
		Statement stmt = null;   
		Connection conn = SQLConnection.getDBConnection();  
		String query = "INSERT INTO RESERVATION (parking_id,payment_id,start_time,end_time,hascart,hascamera,hashistory,iscanceled,isdeleted,total_price) ";					
		query += " VALUES ("  
				+ reservation.getParkingId() + ","
				+ reservation.getPaymentId() + ",'"		
				+ reservation.getStartTimeAsString() + "','"
				+ reservation.getEndTimeAsString() + "'," 
				+ reservation.getHasCart() + ","
				+ reservation.getHasCamera() + ","
				+ reservation.getHasHistory() + ","
				+ reservation.getIsDeleted() + ","
				+ reservation.getTotalPrice() + ")" ;
		PreparedStatement pstmt;
		int key = 0;
		try {
			conn = SQLConnection.getDBConnection();  
			conn.setAutoCommit(false);  
			pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);			  
			pstmt.executeUpdate();
			ResultSet keys = pstmt.getGeneratedKeys();		 
			keys.next();
			key = keys.getInt(1);
			keys.close();
			pstmt.close();
			conn.commit();	
			conn.close();
		} 
		catch (Exception e) { 
				e.printStackTrace(); 
		}
		finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
         }
		return key;
}
	
	//manager view all RRs
	public static ArrayList<ReservationDetails> getAllReservations() {
		String query = " SELECT reservation.id as id,username,parking.name as name,capacity,floor,start_time,end_time,hascart,hascamera,hashistory,total_price"
				+ " FROM reservation,user,parking,payment"
				+ " WHERE payment.id=reservation.payment_id AND payment.user_id=user.id AND parking.id=reservation.parking_id" 
				+ " AND iscanceled!=1 AND isdeleted !=1 ORDER BY start_time DESC";
		return getReservations(query);
	}
	
	//manager filter RRs
    public static ArrayList<ReservationDetails> getAllReservationsByDate(String searchStart, String searchEnd) {
    	String query = " SELECT reservation.id as id,username,parking.name as name,capacity,floor,start_time,end_time,hascart,hascamera,hashistory,total_price"
				+ " FROM reservation,user,parking,payment"
				+ " WHERE payment.id=reservation.payment_id AND payment.user_id=user.id AND parking.id=reservation.parking_id" 
				+ " AND iscanceled!=1 AND isdeleted !=1 AND start_time <= '"+searchEnd+"' and '"+searchStart+"' <= end_time"
				+ " ORDER BY start_time DESC";
    	
		return getReservations(query);
	}
	
	//customer view my RRs
	public static ArrayList<ReservationDetails> getAllMyReservations(int userID) {
		String query = " SELECT reservation.id as id,username,parking.name as name,capacity,floor,start_time,end_time,hascart,hascamera,hashistory,total_price"
				+ " FROM reservation,user,parking,payment"
				+ " WHERE payment.id=reservation.payment_id AND payment.user_id=user.id AND parking.id=reservation.parking_id" 
				+ " AND iscanceled!=1 AND isdeleted !=1 AND user.id="+userID+" ORDER BY start_time DESC";
		return getReservations(query);
	}
	
	//customer filter my RRs
    public static ArrayList<ReservationDetails> getAllMyReservationsByDate(int userID, String searchStart, String searchEnd) {
    	
    	String query = " SELECT reservation.id as id,username,parking.name as name,capacity,floor,start_time,end_time,hascart,hascamera,hashistory,total_price"
				+ " FROM reservation,user,parking,payment"
				+ " WHERE payment.id=reservation.payment_id AND payment.user_id=user.id AND car.id=reservation.car_id" 
				+ " AND iscanceled!=1 AND isdeleted !=1  AND user.id="+userID+" AND start_time <= '"+searchEnd+"' and '"+searchStart+"' <= end_time"
				+ " ORDER BY start_time DESC";
    	
		return getReservations(query);
	}
	
	//retrieve list of RRs from DB
	private static ArrayList<ReservationDetails> getReservations(String query) {
		
		ArrayList<ReservationDetails> resultList = new ArrayList<ReservationDetails>();	
		Statement stmt = null;   
		Connection conn = null;  	
		try {   
			conn = SQLConnection.getDBConnection();  
			stmt = conn.createStatement();
			ResultSet reservationList = stmt.executeQuery(query);
			while(reservationList.next()) {
				ReservationDetails reservationDetails = new ReservationDetails();
				int id = reservationList.getInt("id");
				String username = reservationList.getString("username");
				String parkingName  = reservationList.getString("name");
				int capacity  = reservationList.getInt("capacity");
				int floor  = reservationList.getInt("floor");
				String startTimeAsString = reservationList.getTimestamp("start_time").toLocalDateTime().toString();
				String endTimeAsString = reservationList.getTimestamp("end_time").toLocalDateTime().toString();
				int hasCart  = reservationList.getInt("hascart");
				int hasCamera  = reservationList.getInt("hascamera");
				int hasHistory  = reservationList.getInt("hashistory");
				double totalPrice = reservationList.getDouble("total_price");
				
				reservationDetails.setReservationDetails(id,username, parkingName, capacity, floor, hasCart, hasCamera, hasHistory,
						startTimeAsString, endTimeAsString,totalPrice);					
				
				resultList.add(reservationDetails);
			}
			
			} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};

		return resultList;
	}
	
	
	//retrieve a specific RR from DB
	public static ReservationDetails getReservationById(int resId) {
			
			ReservationDetails reservationDetails = new ReservationDetails();
			Statement stmt = null;   
			Connection conn = null;  	
			String query = " SELECT reservation.id as id,username,parking.name as name,capacity,floor,start_time,end_time,hascart,hascamera,hashistory,total_price"
					+ " FROM reservation,user,parking,payment"
					+ " WHERE reservation.id="+resId+" AND payment.id=reservation.payment_id AND payment.user_id=user.id AND parking.id=reservation.parking_id" 
					+ " AND iscanceled!=1 AND isdeleted !=1 ORDER BY start_time DESC";
			try {   
				conn = SQLConnection.getDBConnection();  
				stmt = conn.createStatement();
				ResultSet reservationList = stmt.executeQuery(query);
				while(reservationList.next()) {
					int id = reservationList.getInt("id");
					String username = reservationList.getString("username");
					String parkingareaName  = reservationList.getString("name");
					int capacity  = reservationList.getInt("capacity");
					int floor  = reservationList.getInt("floor");
					String startTimeAsString = reservationList.getTimestamp("start_time").toLocalDateTime().toString();
					String endTimeAsString = reservationList.getTimestamp("end_time").toLocalDateTime().toString();
					int hasCamera  = reservationList.getInt("hascamera");
					int hasCart  = reservationList.getInt("hascart");
					int hasHistory  = reservationList.getInt("hashistory");
					double totalPrice = reservationList.getDouble("total_price");
					
					
					reservationDetails.setReservationDetails(id,username, parkingareaName, capacity, floor, hasCart, hasCamera, hasHistory,
							startTimeAsString, endTimeAsString,totalPrice);					
					
							
				}
				
				} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					conn.close();
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}};

			return reservationDetails;
	}
		
	
	//customer cancel RR
	public static void cancelReservation(int resId) {
		String query = "UPDATE reservation SET iscanceled=1 WHERE id="+resId;
		removeReservation(query);
	}
	//manager delete RR
	public static void deleteReservation(int resId) {
		String query = "UPDATE reservation SET isdeleted=1 WHERE id="+resId;
		removeReservation(query);
	}
	
	//update RR as canceled or deleted in DB
	private static void removeReservation(String query) {
		Statement stmt = null;   
		Connection conn = SQLConnection.getDBConnection();  
		try {   
			conn = SQLConnection.getDBConnection();  
			conn.setAutoCommit(false);   
			stmt = conn.createStatement();
			stmt.executeUpdate(query);
			conn.commit();					 
		} catch (SQLException sqle) { 
			sqle.printStackTrace();
		} finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			};
		}					
	}	

}
