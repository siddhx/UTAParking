package arlington_parking_app.data;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import arlington_parking_app.model.Parking;
import arlington_parking_app.util.SQLConnection;

public class ParkingDAO {
	
	static SQLConnection DBMgr = SQLConnection.getInstance();
	public static Parking getParkingById(int parkingId) {
		Statement stmt = null;   
		Connection conn = null;  
		Parking parking = new Parking();
		try {   
			conn = SQLConnection.getDBConnection();  
			stmt = conn.createStatement();
			String query = " SELECT * from PARKING WHERE id = '"+parkingId+"'";
			ResultSet parkingList = stmt.executeQuery(query);
			while(parkingList.next()) {
				int id = parkingList.getInt("id");
				String parkingarea_name = parkingList.getString("parkingarea_name");
				int capacity  = parkingList.getInt("capacity");
				double cartRate  = parkingList.getDouble("cart_rate");
				double cameraRate  = parkingList.getDouble("camera_rate");
				double historyRate  = parkingList.getDouble("history_rate");
	
				parking.setId(id);
				parking.setParkingarea_name(parkingarea_name);
				parking.setCapacity(capacity);
				parking.setCartRate(cartRate);
				parking.setCameraRate(cameraRate);
				parking.setHistoryRate(historyRate);
				
			}
			
			} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		return parking;
	}

	public static ArrayList<Parking> getAllAvailableParkingSpots (String searchStart, String searchEnd) { 	
    	
    	String query = "SELECT id, parking.name,capacity,cart_rate,camera_rate,history_rate"
    	     + " FROM parking WHERE parking.id NOT IN ( SELECT parking_id FROM reservation "
	         + " WHERE start_time <= '"+searchEnd+"' and '"+searchStart+"' <= end_time  "
	         + " AND iscanceled!=1 AND isdeleted!=1)"
    		 + " ORDER BY parking.name";
    	
		return getParkingList(query);
	}
	
	//manager view all cars (sorted by car capacity)
	public static ArrayList<Parking> getAllParkings () {
	    	String query = "SELECT id, parking.name,capacity,cart_rate,camera_rate,history_rate"
	    	     + " FROM parking ORDER BY parking.capacity";   	
			return getParkingList(query);
		}
	
	//customer available cars (sorted by capacity)
	public static ArrayList<Parking> getAvailableParkingCustomer(int capacity,
			String searchStart, String searchEnd) {	
    	String query = "SELECT id, parking.name,capacity,cart_rate,camera_rate,history_rate"
    	     + " FROM parking WHERE capacity>="+capacity+" AND parking.id NOT IN ( SELECT parking_id FROM reservation "
	         + " WHERE start_time <= '"+searchEnd+"' AND '"+searchStart+"' <= end_time  "
	         + " AND iscanceled!=1 AND isdeleted!=1)"
    		 + " ORDER BY parking.capacity";
    	
		return getParkingList(query);
	}

	private static ArrayList<Parking> getParkingList(String query) {
		Statement stmt = null;   
		Connection conn = null;  
		ArrayList<Parking> parkingList = new ArrayList<Parking>();

		try {   
			conn = SQLConnection.getDBConnection();  
			stmt = conn.createStatement();
			ResultSet resultList = stmt.executeQuery(query);
			while (resultList.next()) {
				Parking parking = new Parking(); 	
				
				int id = resultList.getInt("id");
				String parkingareaName  = resultList.getString("parkingarea_name");
				int capacity  = resultList.getInt("capacity");
				double cameraRate = resultList.getDouble("camera_rate");
				double cartRate = resultList.getDouble("cart_rate");
				double historyRate = resultList.getDouble("history_rate");
				parking.setId(id);
				parking.setParkingarea_name(parkingareaName);
				parking.setCapacity(capacity);
				parking.setCameraRate(cameraRate);
				parking.setCartRate(cartRate);
				parking.setHistoryRate(historyRate);
				
				
				parkingList.add(parking);
			} 
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		return parkingList;
	}
	
	
	
	public static void addNewParking(Parking car) {
		Statement stmt = null;   
		Connection conn = SQLConnection.getDBConnection();  
		String addParking = "INSERT INTO PARKING (parkingarea_name,capacity,camera_rate,history_rate) ";					
		addParking += " VALUES ('"  
				+ car.getParkingarea_name() + "',"
				+ car.getCapacity() + ","		
				+ car.getCameraRate() + ","
				+ car.getHistoryRate() + ")" 		
				 ;
		try {   
		conn = SQLConnection.getDBConnection();  
		conn.setAutoCommit(false);   
		stmt = conn.createStatement();
		stmt.executeUpdate(addParking);
		conn.commit();					 
	} catch (SQLException sqle) { 
		sqle.printStackTrace();
	} finally {
		try {
			conn.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		};
	}
	}	
	
	
	public static void deleteParking(String parkingName) {
		Statement stmt = null;   
		Connection conn = null;  
		try {   
			conn = SQLConnection.getDBConnection();  
			stmt = conn.createStatement();
			String delete = " DELETE from PARKING WHERE name = '"+parkingName+"' LIMIT 1 ";
			stmt.executeUpdate(delete);
			conn.commit();			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		}
	
}