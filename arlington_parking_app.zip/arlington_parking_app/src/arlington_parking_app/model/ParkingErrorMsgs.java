package arlington_parking_app.model;

public class ParkingErrorMsgs {
	private String errorMsg;
	private String parkingarea_nameError;
	private String capacityError;
	private String cartRateError;
	private String cameraRateError;
	private String historyError;

	public ParkingErrorMsgs () { 
		this.parkingarea_nameError="";
		this.capacityError="";
		this.cartRateError="";
		this.cameraRateError="";
		this.historyError="";
		this.errorMsg="";
	}
	public void setErrorMsg() {
		if (!parkingarea_nameError.equals("") || !capacityError.equals("") || !cartRateError.equals("") 
			|| !cameraRateError.equals("") || !historyError.equals("") )
		  errorMsg="Please correct the following errors";
	}	
	public String getErrorMsg() {return errorMsg;}
	public String getCapacityError() {return capacityError;}
	public void setCapacityError(String capacityError) {this.capacityError = capacityError;}
	public String getParkingarea_nameError() {return parkingarea_nameError;}	
	public void setParkingarea_nameError(String parkingarea_Error) {this.parkingarea_nameError = parkingarea_nameError;}
	public String getCartRateError() {return cartRateError;}	
	public void setCartRateError(String cartRateError) {this.cartRateError = cartRateError;}
	public String getCameraRateError() {return cameraRateError;}	
	public void setCameraRateError(String cameraRateError) {this.cameraRateError = cameraRateError;}
	public void setHistoryRateError(String historyError) {this.historyError = historyError;}
	
}