package arlington_parking_app.model;
import java.io.Serializable;
import arlington_parking_app.data.ParkingDAO;

public class Parking implements Serializable {
	private static final long serialVersionUID = 2L;
	private int id;
	private String parkingarea_name;
	private int capacity;
	private double cartRate;
	private double cameraRate;
	private double historyRate;
	private String capacityAsString;
	private String historyRateAsString;
	private String cameraRateAsString;
	private String cartRateAsString;


	public int getId() { return id; }
	public void setId(int id) { this.id=id; }
	
	public String getParkingarea_name() { return parkingarea_name; }
	public void setParkingarea_name(String parkingarea_name) { this.parkingarea_name = parkingarea_name; }

	public int getCapacity() { return capacity; }
	public void setCapacity(int capacity) { this.capacity = capacity; }

	public double getCameraRate() {return cameraRate;}
	public void setCameraRate(double cameraRate) {this.cameraRate = cameraRate;}

	public double getHistoryRate() {return historyRate;}
	public void setHistoryRate(double historyRate) {this.historyRate = historyRate;}


	/************ VALIDATIONS *************/	
	public void validateParking(Parking parking, ParkingErrorMsgs errorMsgs) {	
		errorMsgs.setParkingarea_nameError(validateName(parking.getParkingarea_name()));
		errorMsgs.setCapacityError(validateCapacity(parking.getCapacityAsString()));
		errorMsgs.setCameraRateError(validateCameraRate(parking.getCameraRateAsString()));
		errorMsgs.setHistoryRateError(validateHistoryRate(parking.getHistoryRateAsString()));

		validateCapacity(parking,errorMsgs);
	}	
	public void validateCapacity(Parking parking, ParkingErrorMsgs errorMsgs) {		
		errorMsgs.setCapacityError(validateCapacity(parking.getCapacityAsString()));
		errorMsgs.setErrorMsg();
	}	
	private String validateName (String name) {
		name = name.trim(); 
		String result="";
		if (!stringSize(name,2,50))
			result= "Parking Name must between 2 and 50 characters";
		else
			if (!name.matches("^[a-zA-Z0-9]+$"))
				result="Parking Name must only contain alphabets and numbers";
	
		return result;	
	}		
	private String validateCapacity(String capacityAsString) {
		String result = "";
		if(!isTextAnInteger(capacityAsString))
			result="Car Capacity must be a whole number";
		else {
			this.setCapacity(Integer.parseInt(capacityAsString));		
			if (capacity < 1 || capacity > 30)
				result="Car Capacity must be between 1 and 30";
		}		
		return result;	
	}	
	private String validateCartRate(String cartAsString) {
        String result="";		
		if(!isTextADouble(cartRateAsString))
			result= "Cart Rate must be a number";	
		else {
		    this.setCartRate(Double.parseDouble(cartRateAsString));			
			if (cartRate < 15.95)
				result= "Cart Rate cannot be less than $15.95";
			else
				if(cartRate > 15.95) 
					result= "Weekd Rate cannot be greater than $15.95";
		}				
		return result;
	}	
	private String validateCameraRate(String cameraRateAsString) {
        String result="";		
		if(!isTextADouble(cameraRateAsString))
			result= "Camera Rate must be a number";	
		else {
		    this.setCameraRate(Double.parseDouble(cameraRateAsString));			
			if (cameraRate < 2.95)
				result= "Camera Rate cannot be less than $2.95";
			else
				if(cameraRate > 2.95) 
					result= "Camera Rate cannot be greater than $2.95";
		}				
		return result;
	}	
	private String validateHistoryRate(String historyRateAsString) {
        String result="";		
		if(!isTextADouble(historyRateAsString))
			result= "History Rate must be a number";	
		else {
			this.setHistoryRate(Double.parseDouble(historyRateAsString));						
			if (historyRate < 1.95)
				result= "History Rate cannot be less than $1.95";
			else
				if(historyRate > 1.95) 
					result= "History Rate cannot be greater than $1.95";
		}				
		return result;
	}	

	
	
   /************* AUXILIARY FUNCTIONS *************/	
	private boolean stringSize(String string, int min, int max) {
		return string.length()>=min && string.length()<=max;
	}
	private boolean isTextAnInteger (String string) {
        boolean result;
		try {
            Long.parseLong(string);
            result=true;
        } 
        catch (NumberFormatException e) {
            result=false;
        }
		return result;
	}	
	private boolean isTextADouble(String string) {
        boolean result;
		try {
            Double.parseDouble(string);
            result=true;
        } 
        catch (NumberFormatException e)  {
            result=false;
        }
		return result;
	}
	public String getCapacityAsString() {
		return capacityAsString;
	}
	public void setCapacityAsString(String capacityAsString) {
		this.capacityAsString = capacityAsString;
	}
	public double getCartRate() {
		return cartRate;
	}
	public void setCartRate(double cartRate) {
		this.cartRate = cartRate;
	}
	public String getHistoryRateAsString() {
		return historyRateAsString;
	}
	public void setHistoryRateAsString(String historyRateAsString) {
		this.historyRateAsString = historyRateAsString;
	}
	public String getCameraRateAsString() {
		return cameraRateAsString;
	}
	public void setCameraRateAsString(String cameraRateAsString) {
		this.cameraRateAsString = cameraRateAsString;
	}
}
