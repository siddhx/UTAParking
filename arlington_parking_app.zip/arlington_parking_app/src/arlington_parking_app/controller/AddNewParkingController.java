package arlington_parking_app.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import arlington_parking_app.data.ParkingDAO;
import arlington_parking_app.model.*;

@WebServlet("/AddNewParkingController")
public class AddNewParkingController extends HttpServlet {

	private static final long serialVersionUID = 6L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();
		String action = request.getParameter("action");
		String url = "/addNewParkingSpot.jsp";
		
		if(action.equalsIgnoreCase("addNewParkingSpot")) {
			if (request.getParameter("addParkingBtn")!=null) 
			{
				Parking parking = new Parking();	

				parking.setParkingarea_name(request.getParameter("parkingarea_name"));
				parking.setCapacityAsString(request.getParameter("capacity"));
				parking.setCameraRateAsString(request.getParameter("cameraRate"));
				parking.setHistoryRateAsString(request.getParameter("historyRate"));
				
				ParkingErrorMsgs PerrorMsgs = new ParkingErrorMsgs();
				parking.validateParking(parking, PerrorMsgs);
				session.setAttribute("Parking",parking);
				session.setAttribute("errorMsgs",PerrorMsgs);
				if (PerrorMsgs.getErrorMsg().equals("")) {
					
					ParkingDAO.addNewParking(parking); 
					session.removeAttribute("Parking");
					session.removeAttribute("errorMsgs");
				}
			}
			else //done button pressed
			{
				session.removeAttribute("Parking");
				session.removeAttribute("errorMsgs");
				url = "/managerHome.jsp";
			}
		}
		
		else if(action.equalsIgnoreCase("goHome")) {
			session.removeAttribute("Parking");
			session.removeAttribute("errorMsgs");
			url="/managerHome.jsp";
		}
		
		else //redirect all other posts to get
			doGet(request,response);
		
		getServletContext().getRequestDispatcher(url).forward(request, response);
			
	}
}