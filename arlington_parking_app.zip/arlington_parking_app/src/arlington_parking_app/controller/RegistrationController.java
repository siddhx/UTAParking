package arlington_parking_app.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import arlington_parking_app.data.UserDAO;
import arlington_parking_app.model.*;

@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {

	private static final long serialVersionUID = 3L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response); 
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();	
		String action = request.getParameter("action");
		String url = "/register.jsp";
		
		if(action.equalsIgnoreCase("register"))
		{
			
			User user = new User();
			
			//set user attributes
			user.setFirstName(request.getParameter("firstName"));
			user.setLastName(request.getParameter("lastName"));
			user.setUsername(request.getParameter("username"));
			user.setPassword(request.getParameter("password"));
			user.setEmail(request.getParameter("email"));
			user.setUtaId(request.getParameter("utaId"));
			user.setPhone(request.getParameter("phone")); 
			user.setParkingpermitype(request.getParameter("parkingpermitype")); 
			user.setRole(request.getParameter("role"));
			user.setCity(request.getParameter("city"));
			user.setAddress(request.getParameter("address"));
			user.setState(request.getParameter("state"));
			user.setZipcode(request.getParameter("zipcode"));
		
			UserErrorMsgs UerrorMsgs = new UserErrorMsgs();
			user.validateUser(user, UerrorMsgs, action);
			session.setAttribute("User",user);
			session.setAttribute("errorMsgs",UerrorMsgs);
			if (UerrorMsgs.getErrorMsg().equals("")) {
				UserDAO.registerUser(user); //save employee if no errors
				session.removeAttribute("User");
				session.removeAttribute("errorMsgs");
				url = "/login.jsp"; //if successful, redirect to login page
			}				
			
		}		
		
		else if(action.equalsIgnoreCase("goHome")) {
			session.removeAttribute("User");
			session.removeAttribute("errorMsgs");
			url="/login.jsp";
		}
		else // redirect all other posts to get
			doGet(request,response);

		getServletContext().getRequestDispatcher(url).forward(request, response);
			
	}
}