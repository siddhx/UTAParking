package arlington_parking_app.controller;

public class ViewAllParkingSpotController {

}
