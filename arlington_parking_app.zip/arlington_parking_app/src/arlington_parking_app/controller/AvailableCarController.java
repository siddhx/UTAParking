package arlington_parking_app.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import arlington_parking_app.model.Parking;
import arlington_parking_app.model.ReservationErrorMsgs;
import arlington_parking_app.data.ParkingDAO;
import arlington_parking_app.model.Reservation;


@WebServlet("/AvailableCarController")
public class AvailableCarController extends HttpServlet {
	private static final long serialVersionUID = 8L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String action = request.getParameter("action");
		String url="/availableCars.jsp";
		
		ArrayList<Parking> availableCarList = new ArrayList<Parking>();
		
		//List ALL available cars
		if (action.equalsIgnoreCase("viewAvailableCars")) 
		{																
			if(request.getParameter("searchBtn2")!=null) {				
				String selectedStartTime = request.getParameter("startTime");
				String selectedEndTime = request.getParameter("endTime");
				
				//validate start/end time
				Reservation reservation = new Reservation();
				reservation.setStartTimeAsString(selectedStartTime);
				reservation.setEndTimeAsString(selectedEndTime);			
				ReservationErrorMsgs RerrorMsgs = new ReservationErrorMsgs();
				reservation.validateViewFilterTimes(reservation, RerrorMsgs);
				session.setAttribute("Reservation",reservation);
				session.setAttribute("errorMsgs",RerrorMsgs);
				
				if (RerrorMsgs.getErrorMsg().equals("")) {	
					session.removeAttribute("errorMsgs");
					availableCarList = ParkingDAO.getAllAvailableCars
							(reservation.getStartTimeAsString(), reservation.getEndTimeAsString()); 
					session.setAttribute("CARS", availableCarList);						
				}				
				
			}	
			
			else if(request.getParameter("clearBtn3")!=null) {
				session.removeAttribute("errorMsgs");
				session.removeAttribute("Reservation");
				session.removeAttribute("CARS");
			}
			
		}
		
		else if(action.equalsIgnoreCase("goHome")) {
			session.removeAttribute("Reservation");
			session.removeAttribute("errorMsgs");	
			session.removeAttribute("CARS");
			url="/managerHome.jsp";
		}

		else // redirect all other posts to get
			doGet(request,response);
		
		getServletContext().getRequestDispatcher(url).forward(request, response);

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);		
	}

}

