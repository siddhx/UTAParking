package M06;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class Problem1Test {
Problem1 prb1;
@Before
public void setUp() throws Exception {
prb1 = new Problem1();
}
@Test
@FileParameters("src/M06/Problem1TestCases.csv")
public void test(int testCaseNumber, boolean a, boolean b, boolean c, int expReturn, String bPath) {
assertEquals(expReturn,prb1.returnTrue(a, b, c));
}
}