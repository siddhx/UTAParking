package M06;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class ExerciseE03Test {
ExerciseE03 prb3;
@Before
public void setUp() throws Exception {
prb3 = new ExerciseE03();
}
@Test
@FileParameters("src/M06/ExerciseE03TestCases.csv")
public void test(int testCaseNumber, double a, boolean b, boolean c, boolean d, double expReturn, String bPath) {
assertEquals(expReturn,prb3.calcTotal(a, b, c, d),0.1);
}
}