package M06;

public class Problem2 {
	
	private boolean memberBonus;
	private double total;

	public void determineMemberBonus (double cart, boolean firstTimeBuyer, boolean goldStatus, int bonusPoints, double taxRate) {
		double discount;
		if (cart <= 500.00)
			discount = 0.0;
		else
			if (cart < 1_500.00)
				discount = 0.10;
			else
				if (cart <= 2_500.00)
					discount = 0.15;
				else
					if (cart < 3_500.00)
						discount = 0.20;
					else
						discount = 0.25;
		total = (1+taxRate)*cart*(1.0-discount);
		
		memberBonus = firstTimeBuyer || (cart > 5_000.00 && bonusPoints > 500) || goldStatus;	
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public boolean isMemberBonus() {
		return memberBonus;
	}
	public void setMemberBonus(boolean memberBonus) {
		this.memberBonus = memberBonus;
	}
}