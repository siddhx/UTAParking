package M06;

import static org.junit.Assert.*;

import org.junit.Test;

public class Problem2Test {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
