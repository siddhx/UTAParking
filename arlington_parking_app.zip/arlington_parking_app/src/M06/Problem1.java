package M06;

public class Problem1 {

	public int returnTrue (boolean a, boolean b, boolean c) {
		int result=0;
		if (a)
			result++;
		if (b)
			result++;
		if (c)
			result++;
		return result;
	}
}