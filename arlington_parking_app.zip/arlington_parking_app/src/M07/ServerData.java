package M07;

public interface ServerData {
	public double getTotal();
}
