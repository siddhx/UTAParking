package M07;

import static org.junit.Assert.*;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
@RunWith(JUnitParamsRunner.class)
public class ExerciseE04Test {


	ExerciseE04 prb4;
	ServerData mockobj;
	@Before
	public void setUp() throws Exception {
	prb4 = new ExerciseE04();
	mockobj = EasyMock.strictMock(ServerData.class);
	}
	@FileParameters("src/M07/ExerciseE04TestCases.csv")
	@Test
	public void testDetermineCalcTotal(int testCaseNumber, double a, boolean b, boolean c, boolean d, double expReturn, String bPath) {
	EasyMock.expect(mockobj.getTotal()).andReturn(a);
	EasyMock.replay(mockobj);
	double obj=prb4.calcTotal(mockobj,b,c,d);
	assertEquals(expReturn,obj,0.1);
	}
	}


