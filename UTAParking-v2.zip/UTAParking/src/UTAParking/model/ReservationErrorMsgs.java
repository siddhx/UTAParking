package UTAParking.model;

public class ReservationErrorMsgs 
{
	private String generalErrorMsg;
	private int id;
	private String parkingTypeError;
	private String parkingAreaNameError;
	private int capacity;
	private int floor;
	private float cart;
	private float camera;
	private float history;
}
